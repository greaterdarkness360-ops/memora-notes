# Panduan Pemasangan Upgrade Memora Notes

Paket ini berisi seluruh 11 file pembaruan untuk menambahkan:
1. Pilihan Pengingat: **Notifikasi Biasa** vs **Alarm (Dering Keras + Getaran Berulang)** dengan layar penuh & tombol Matikan / Tunda 10 Menit.
2. **Mode Gelap Tanpa Hiasan** dengan tombol sakelar di header yang tersimpan permanen di `localStorage`.
3. **Widget Home Screen Android** yang ikut berubah tema (Sweet Pink Light <-> Minimalist Dark).

## Cara Memasang (Pilih Salah Satu)

### Cara 1 — Via Git Lokal (Paling Cepat)
1. Ekstrak seluruh isi ZIP ini langsung ke dalam folder root repositori `memora-notes` Anda (pilih **Replace / Timpa** file yang sudah ada).
2. Jalankan perintah berikut:
   ```bash
   git add .
   git commit -m "Add native alarm with vibration, minimalist dark mode, and dark widget"
   git push origin main
   ```
3. Buka tab **Actions** di GitHub (`Build Android APK (Memora Notes)`) dan unduh artifact `Memora-App-Debug` setelah build hijau.

### Cara 2 — Via GitHub Web
Unggah/perbarui 11 file sesuai struktur foldernya ke branch `main`:
- `index.html`
- `src/assets/main.css`
- `src/types/note.ts`
- `src/services/notification.ts`
- `src/App.vue`
- `src/components/QuickAddBar.vue`
- `src/components/NoteCard.vue`
- `src/components/NoteEditorModal.vue`
- `scripts/setup-widget.js`
- `scripts/setup-alarm.js` (file baru)
- `.github/workflows/build-apk.yml`
